function getProductDetails() {
  var retrievedObject = JSON.parse(localStorage.getItem("selectedProduct"));

  //console.log("selectedProduct: ", JSON.parse(retrievedObject));
  console.log(retrievedObject["titre"]);

  $("#prodTitle").html(retrievedObject["titre"]);
  $("#prodImg").attr(
    "src",
    "http://localhost:8088/trandobackend/web/bundles/images/" +
      retrievedObject["images"][0]["image"]
  );
  $("#date").html("Posted: " + retrievedObject["date"]);
  $("#phone").html("Contact: " + retrievedObject["contact"]);
  $("#type").html("Type: " + retrievedObject["type"]);
  $("#prodPrice").html(retrievedObject["prix"] + "DT");
  $("#prodDes").html(retrievedObject["description"]);
}
