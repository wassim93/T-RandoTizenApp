var selectedProduct;
function getData() {
  var xhr = new XMLHttpRequest();
  var url = "http://localhost:8000/GetAllProduct";
  xhr.open("GET", url, true);
  xhr.onreadystatechange = function() {
    if (xhr.readyState === 4 && xhr.status === 200) {
      var response = JSON.parse(xhr.responseText);
      appendData(response);
    } else {
      console.log("err" + response);
    }
  };
  xhr.send();
}

function appendData(response) {
  var ul = document.getElementById("products");
  for (var i = 0; i <= response.length; i++) {
    var li = document.createElement("li");
    li.setAttribute("id", response[i]["id"]);
    li.setAttribute("class", "product");
    var a = document.createElement("a");
    a.setAttribute("href", "#");
    //stringify all json object as an id
    a.setAttribute("id", JSON.stringify(response[i]));
    a.setAttribute("onclick", "showProductDetail(this.id);");
    var img = document.createElement("img");
    img.setAttribute(
      "src",
      "http://localhost:8088/trandobackend/web/bundles/images/" +
        response[i]["images"][0]["image"]
    );
    img.setAttribute("style", "height:200px;width:200px");
    var h3 = document.createElement("h3");
    h3.innerHTML = response[i]["titre"];
    a.appendChild(img);
    a.appendChild(h3);
    var a1 = document.createElement("a");
    a1.setAttribute("href", "shop-detail.html");
    a1.setAttribute("class", "addto-cart");
    a1.setAttribute("title", "More Details");
    a1.innerHTML = "More Details";

    /* <div class="wishlist-box">
            <a href="#"><i class="fa fa-heart-o"></i>28</a>
            <a href="#"><i class="fa fa-cart-plus"></i>36</a>
        </div>*/

    var div = document.createElement("div");
    div.setAttribute("class", "wishlist-box");
    var a2 = document.createElement("a");
    a2.setAttribute("id", response[i]["id"]);
    a2.setAttribute("onclick", "showModal(this.id);");
    //a2.setAttribute("data-toggle", "modal");
    //a2.setAttribute("data-target", "#confirm-delete");

    var icdel = document.createElement("i");
    icdel.setAttribute("class", "fa fa-trash");

    var a3 = document.createElement("a");
    a3.setAttribute("id", "updateBtn");
    a3.setAttribute("onclick", "updateAction();");
    var icup = document.createElement("i");
    icup.setAttribute("class", "fa fa-refresh");

    a2.appendChild(icdel);
    a3.appendChild(icup);
    div.appendChild(a2);
    div.appendChild(a3);
    li.appendChild(a);
    li.appendChild(div);

    li.appendChild(a1);

    ul.appendChild(li);
  }
}

function search() {
  var input, filter, ul, li, a, i;
  input = document.getElementById("searchInput");
  filter = input.value.toUpperCase();
  ul = document.getElementById("products");
  li = ul.getElementsByTagName("li");
  for (i = 0; i < li.length; i++) {
    a = li[i].getElementsByTagName("a")[0];
    if (a.innerHTML.toUpperCase().indexOf(filter) > -1) {
      li[i].style.display = "";
    } else {
      li[i].style.display = "none";
    }
  }
}

function deleteAction() {
  console.log(selectedProduct);
  // delete li from list withoout refreshing
  var selected = document.getElementById(selectedProduct);
  selected.remove();
  hideModal();

  // Delete a user
  var url = "http://localhost:8000/deleteProduct/" + selectedProduct;
  var xhr = new XMLHttpRequest();
  xhr.open("GET", url, true);
  xhr.onload = function() {
    // var users = JSON.parse();
    if (xhr.readyState == 4 && xhr.status == "200") {
      console.log(xhr.responseText);
    } else {
      console.log(xhr.responseText);
    }
  };
  xhr.send();
}

function showModal(id) {
  $("#confirm-delete").modal("show");
  selectedProduct = id;
}

function hideModal() {
  $("#confirm-delete").modal("hide");
}

function showProductDetail(data) {
  console.log(data);
  localStorage.setItem("selectedProduct", data);
  window.location.href = "shop-detail.html";
}
